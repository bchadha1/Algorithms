import sys
class Graph:
    def __init__(self, vertices):
        self.V = vertices
        self.graph = [[0 for column in range(vertices)]
                      for row in range(vertices)]

    def printMST(self, parent):
        print("Edge \tWeight")
        for i in range(1, self.V):
            print(parent[i], 'to', i, ' = ', self.graph[i][parent[i]])

    def minKey(self, key, mstSet):
        global minimum_index
        min = sys.maxint
        for v in range(self.V):
            if key[v] < min and mstSet[v] == False:
                min = key[v]
                minimum_index = v

        return minimum_index

    def primMST(self):

        key = [sys.maxint] * self.V
        parent = [None] * self.V  # Array to store constructed MST
        key[0] = 0
        mstSet = [False] * self.V

        parent[0] = -1  # First node is always the root of

        for cout in range(self.V):

            u = self.minKey(key, mstSet)
            mstSet[u] = True
            for v in range(self.V):
                if 0 < self.graph[u][v] < key[v] and mstSet[v] == False:
                    key[v] = self.graph[u][v]
                    parent[v] = u

        self.printMST(parent)


g = Graph(8)
g.graph = [[0, 1, 0, 0, 4, 8, 0, 0],
           [1, 0, 2, 0, 0, 6, 6, 0],
           [0, 2, 0, 1, 0, 0, 2, 0],
           [0, 0, 1, 0, 0, 0, 1, 4],
           [4, 0, 0, 0, 0, 5, 0, 0],
           [8, 6, 0, 0, 5, 0, 1, 0],
           [0, 6, 2, 1, 0, 1, 0, 1],
           [0, 0, 0, 4, 0, 0, 1, 0]]

g.primMST()
