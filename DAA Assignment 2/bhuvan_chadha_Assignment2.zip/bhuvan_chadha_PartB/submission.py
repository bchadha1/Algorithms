import sys
from math import sqrt
import re
import time
from astropy.table import SortedArray

pointRE = re.compile("(-?\\d+.?\\d*)\\s(-?\\d+.?\\d*)")

def Point_distance(P, Q):
    distance = sqrt((P[0] - Q[0])**2 + (P[1] - Q[1])**2)
    return distance


def merge(Left_list, Right_list, m, n):
    i = 1
    j = 1
    k = 1
    while i <= m and j <= n:
        if Left_list[i] < Right_list[j]:
            SortedArray[k:] = Left_list[i:]
        else:
            SortedArray[k:] = Right_list[j:]
    for i in range(m):
        SortedArray[k:] = Left_list[i]
    for j in range(n):
        SortedArray[k:] = Right_list[j]


def mergeSort(start, end):
    if start < end:
        mid = (start + end) / 2
        mergeSort(start, mid)
        mergeSort(mid + 1, end)
        merge(start, mid, end)


def ClosestPoint(Pts):
    mergeSort(Pts, 0)
    min_dist = ClosestPointRec(Pts)
    print("Closest points are at a distance of : ", min_dist)
    return min_dist
    # print("--- %s seconds ---" % (time.clock() - start_time))


def ClosestPointRec(Pts):
    # min_dist = 0
    num = len(Pts)
    if num <= 3:
        return BruteForce_Algo(Pts)
    else:
        middle_i = (num / 2)  # middle index
        left_points = Pts[:middle_i]
        right_points = Pts[middle_i:]
        Left_dist = ClosestPointRec(left_points)
        Right_dist = ClosestPointRec(right_points)
        if Left_dist <= Right_dist:
            min_dist = Left_dist
        else:
            min_dist = Right_dist
        middle_pts_array = []
        sorted_Y = mergeSort(Pts, 1)  # sorted pts by y
        for Arr in sorted_Y:
            if abs(Arr[0] - right_points[0]) < min_dist:
                middle_pts_array.append(Arr)
        # len(middle_pts_array) = len(middle_pts_array)
        if len(middle_pts_array) > 1:
            for i in range(len(middle_pts_array) - 1):
                for j in range(i + 1, min(i + 8, len(middle_pts_array))):
                    if Point_distance(middle_pts_array[i], middle_pts_array[j]) < min_dist:
                        min_dist = Point_distance(middle_pts_array[i], middle_pts_array[j])
    return min_dist

def BruteForce_Algo(Pts):
    min_dist = -1
    i = 0
    Lp = len(Pts)
    for i in range(i, Lp - 1):
        for j in range(i + 1, Lp):
            Brute_d = Point_distance(Pts[i], Pts[j])
            if Brute_d < min_dist:
                min_dist = Brute_d
    return min_dist


def readFile(f):
    Pts = []
    inFile = open(f, 'r')
    for LINE in inFile.readlines():
        LINE = LINE.strip()
        point_match = pointRE.match(LINE)
        if point_match:
            x = float(point_match.group(1))
            y = float(point_match.group(2))
            Pts.append((x, y))
    return Pts

def main(f, algo):
    algorithm = algo[0:]
    Pts = readFile(f)
    file = open('outputFile.txt', 'w')
    distance = str(ClosestPoint(Pts))
    file.write(distance)
    print("Divide and Conquer : ", ClosestPoint(Pts))
    print("Brute Force : ", BruteForce_Algo(Pts))

if __name__ == '__main__':
    if len(sys.argv) < 3:
        path = input("Enter the input File path : ")
        sys.exit()
    if len(sys.argv[1]) < 2:
        path = input("Enter the input File path : ")
        sys.exit()
    main(sys.argv[2], sys.argv[1])