import itertools
from threading import Thread

#function to check the key
def KeyCheck(A, t, key):
    LocArr = [i for i, item in enumerate(A) if item == key]
    if len(LocArr) > 0:
        for i in LocArr:
                f.write(str(key)+" is the sum of ("+str(t[0])+", "+str(t[1]) +")\n")

#reading the input file
with open('inputFile.txt') as f:
    reader = f.readlines()[0].strip('\n')
    TstLst = filter(None, reader.split(","))
    Arr = list(map(int, TstLst))

#opening writing the output file
f = open("outputFile.txt", "w")

#taking a temporary array L1
L1 = []
for item in itertools.permutations(Arr, 2):
    L1.append(sorted(item))

j = sorted(L1)
SortArr = [j[i] for i in range(len(j)) if i == 0 or j[i] != j[i-1]]

for value in SortArr:
    t = Thread(target=KeyCheck, args=(Arr, value, sum(value)))
    t.start()


f.close()
