README

The program is a given as a python file which can be executed in any python environment (Spyder, Jupyter, PyCharm, etc).
The input file contains the test case which is imported by the program by itself.
The output file is written after the program is run.

Implemented Algorithm:

This program takes an array from a text file, implemented using file handling in python.
The program then reads the array, adds two 'Keys' or elements of the array and campares the sum with every other Key (or item) in the array.
If the function finds the sum of any two keys equal to any item in the array, it returns the value.
The output is stored in the an output file showing the two keys.

Code:
*********************************************************************
import itertools
from threading import Thread

#function to check the key
def KeyCheck(A, t, key):
    LocArr = [i for i, item in enumerate(A) if item == key]
    if len(LocArr) > 0:
        for i in LocArr:
                f.write(str(t[0])+" "+str(t[1]) +"\n")

#reading the input file
with open('inputFile.txt') as f:
    reader = f.readlines()[0].strip('\n')
    TstLst = filter(None, reader.split(","))
    Arr = list(map(int, TstLst)) 

#opening writing the output file
f = open("outputFile.txt", "w")

#taking a temporary array L1
L1 = []
for item in itertools.permutations(Arr, 2):
    L1.append(sorted(item))

j = sorted(L1)
SortArr = [j[i] for i in range(len(j)) if i == 0 or j[i] != j[i-1]]

for val in SortArr:
    t = Thread(target=KeyCheck, args=(Arr,val,sum(val)))
    t.start()


f.close()
*********************************************************************


CODE RUN:
>>python <KeyCheck>.py

Input File: inputFile.txt
Output File: outputFile.txt